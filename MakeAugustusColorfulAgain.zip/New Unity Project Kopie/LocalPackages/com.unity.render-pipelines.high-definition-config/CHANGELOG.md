# Changelog
All notable changes to this package will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## [7.3.1] - 2020-03-11

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [7.2.0] - 2020-02-10

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [7.1.1] - 2019-09-05

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [7.0.1] - 2019-07-25

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

Started Changelog
