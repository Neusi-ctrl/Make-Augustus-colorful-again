﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SliderUpdate : MonoBehaviour
{
    public PaintAugustus PaintAugustus;
    //GameObject brushsize;
   

    public void changeValue()
    {
        //PaintAugustus.f = PaintAugustus.brushsize.GetComponent<Slider>().value;
       
    }
}
