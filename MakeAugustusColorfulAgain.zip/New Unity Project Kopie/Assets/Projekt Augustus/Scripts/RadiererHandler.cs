﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RadiererHandler : MonoBehaviour
{
    public PaintAugustus PaintAugustus;
    

    public void ColorFrame()
    {
        if (PaintAugustus.Pinsel != null && PaintAugustus.Radierer != null)
        {
            PaintAugustus.Radierer.SetActive(!PaintAugustus.b);
            PaintAugustus.Pinsel.SetActive(PaintAugustus.b);
        }
    }
}
