﻿using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class BlitFeature : ScriptableRendererFeature
{
    [System.Serializable]
    public class FeatureSettings
    {
        public Texture renderTexture;
        public Texture permanentTexture;
    }

    class PreRenderPass : ScriptableRenderPass
    {
        FeatureSettings settings;

        public PreRenderPass(FeatureSettings settings)
        {
            this.settings = settings;
            this.renderPassEvent = RenderPassEvent.BeforeRenderingTransparents;
        }

        public override void Configure(CommandBuffer cmd, RenderTextureDescriptor cameraTextureDescriptor)
        {
        }

        public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
        {
            CommandBuffer cmd = CommandBufferPool.Get();
            cmd.Clear();

            cmd.Blit(settings.permanentTexture, settings.renderTexture);

            context.ExecuteCommandBuffer(cmd);

            cmd.Clear();
            CommandBufferPool.Release(cmd);
        }

        public override void FrameCleanup(CommandBuffer cmd)
        {
        }
    }

    class PostRenderPass : ScriptableRenderPass
    {
        FeatureSettings settings;

        public PostRenderPass(FeatureSettings settings)
        {
            this.settings = settings;
            this.renderPassEvent = RenderPassEvent.AfterRenderingTransparents;
        }

        public override void Configure(CommandBuffer cmd, RenderTextureDescriptor cameraTextureDescriptor)
        {
        }

        public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
        {
            CommandBuffer cmd = CommandBufferPool.Get();
            cmd.Clear();

            cmd.Blit(settings.renderTexture, settings.permanentTexture);

            context.ExecuteCommandBuffer(cmd);

            cmd.Clear();
            CommandBufferPool.Release(cmd);
        }

        public override void FrameCleanup(CommandBuffer cmd)
        {
        }
    }


    // MUST be named "settings" (lowercase) to be shown in the Render Features inspector
    public FeatureSettings settings = new FeatureSettings();


    PreRenderPass preRenderPass;
    PostRenderPass postRenderPass;

    public override void Create()
    {
        preRenderPass = new PreRenderPass(settings);
        postRenderPass = new PostRenderPass(settings);
    }

    // Here you can inject one or multiple render passes in the renderer.
    // This method is called when setting up the renderer once per-camera.
    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        renderer.EnqueuePass(preRenderPass);
        renderer.EnqueuePass(postRenderPass);
    }
}


