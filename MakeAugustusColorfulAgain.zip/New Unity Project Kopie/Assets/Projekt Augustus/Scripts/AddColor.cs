﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;



public class AddColor : MonoBehaviour
{
    //public Button addColor;
    public Color col;
    public Image Auswahlfarbe;
    bool actualColor = false;
    bool nextColor = false;
    public Button[] farben = new Button[5];
    int pos = 0;
    

    public void Start()
    {
        col = Auswahlfarbe.GetComponent<Image>().color;

    }
    public void TaskOnClick()
    {
       
        //if (pf.moved == true && dad.begintomove == true) {
        //        Debug.Log("Objekt wurde verschoben");}
       
        
        if(nextColor == false){
            farben[pos].GetComponent<Button>().GetComponent<Image>().color = Auswahlfarbe.GetComponent<Image>().color;
            if (pos < 4){
                farben[pos + 1].GetComponent<Image>().color = Color.white;
            }
            pos += 1;
            if (pos == 5){
                nextColor = true;
                pos = 0;
            }
        }
        if(nextColor == true){
            farben[pos].GetComponent<Image>().color = Color.white;
            nextColor = false;
        }

    }
}
