﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PinselHandler : MonoBehaviour
{
    public PaintAugustus PaintAugustus;
   
    public void ColorFrame() {

        if (PaintAugustus.Pinsel!= null && PaintAugustus.Radierer != null)
        {
            PaintAugustus.Pinsel.SetActive(!PaintAugustus.b);
            PaintAugustus.Radierer.SetActive(PaintAugustus.b);
            
        }
    }
}
