﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CameraMovement : MonoBehaviour
{
	[SerializeField] private Camera cam;
	[SerializeField] private Transform target;
	private Vector3 previousPosition;
    float zoomOutMin = 0;
    float zoomOutMax = 8;
    float smooth = 5;
    Vector3 touchStart;


    private void Start()
    {
        cam.transform.position = target.position;
        cam.transform.Translate(new Vector3(0, 0, -1));//variable anpassen (-1)
    }
    // Update is called once per frame
    void Update()
    {
        //sobald die rechte Maustaste gedrückt wird, soll der Augustus rotierbar sein 
        if (Input.GetMouseButtonDown(1))
        {
            previousPosition = cam.ScreenToViewportPoint(Input.mousePosition);
        }

        if (Input.GetMouseButton(1))
        {
            Vector3 direction = previousPosition - cam.ScreenToViewportPoint(Input.mousePosition);
            cam.transform.position = target.position;
            cam.transform.Rotate(new Vector3(1, 0, 0), direction.y * 180);
            cam.transform.Rotate(new Vector3(0, 1, 0), -direction.x * 180, Space.World);
            cam.transform.Translate(new Vector3(0, 0, -1));//variable anpassen (-1)

            previousPosition = cam.ScreenToViewportPoint(Input.mousePosition);

        }


        //ZOOM FUNCTION IF DEVICE IS SMARTPHONE OR TABLET
        if (Input.GetMouseButtonDown(0))
        {
            touchStart = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        }
        if (Input.touchCount == 2)
        {
            Touch touchZero = Input.GetTouch(0);
            Touch touchOne = Input.GetTouch(1);

            Vector2 touchZeroPrevPos = touchZero.position - touchZero.deltaPosition;
            Vector2 touchOnePrevPos = touchOne.position - touchOne.deltaPosition;

            float prevMagnitude = (touchZeroPrevPos - touchOnePrevPos).magnitude;
            float currentMagnitude = (touchZero.position - touchOne.position).magnitude;

            float difference = currentMagnitude - prevMagnitude;
            

            zoom(difference);
        }
        else if (Input.GetMouseButton(0))
        {
            Vector3 direction = touchStart - Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Camera.main.transform.position += direction;
        }
        
        zoom(Input.GetAxis("Mouse ScrollWheel"));

    }

    void zoom(float increment)
    {
        //cam.fieldOfView = Mathf.Clamp(cam.fieldOfView - increment, zoomOutMin, zoomOutMax);
        Debug.Log(increment);
        //ZOOM FUNCTION IF DEVICE IS MOUSE 
        if (increment > 0)
        {
            cam.fieldOfView--; //radius setzen
            //cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, zoomIn, Time.deltaTime * smooth);

        }
        if (increment < 0)
        {
            cam.fieldOfView++;
            //cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, zoomOut, Time.deltaTime * smooth);
        }
    }
}

