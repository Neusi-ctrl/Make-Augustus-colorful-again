﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Color_OnClick : MonoBehaviour
{

    public PaintAugustus pa;
    public Button individual_color;
   
    public void ColorOnClick()
    {
        pa.colorPicker.color = individual_color.GetComponent<Image>().color;
        pa.col = individual_color.GetComponent<Image>().color;
        //Debug.Log(individual_color.GetComponent<Image>().color);
        //ToHtmlStringRGB(individual_color.GetComponent<Image>().color);
    }
}
