﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ColorLerp : MonoBehaviour
{
    public GameObject Fill;
    private Image im;
    [Range(0, 1)] public float lerpTime;
    public Color color;
    int colorIndex;
    float time;
    

    private void Update()
    {
        Fill.GetComponent<Image>().color = Color.Lerp(Fill.GetComponent<Image>().color, color, lerpTime * Time.deltaTime);
    }
}

