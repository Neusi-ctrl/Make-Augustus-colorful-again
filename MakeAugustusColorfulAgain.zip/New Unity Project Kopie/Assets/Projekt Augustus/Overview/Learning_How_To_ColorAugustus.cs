﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class Learning_How_To_ColorAugustus : MonoBehaviour
{
    // bool done = false;
    //public Color testColor = new Color(255, 255, 0);
    //public Color textureColor;
    //public Color mixedColor;
    //float alpha;
    public float radius = 0.05f;
    public Texture[] textures;
    Renderer rend;

    // Start is called before the first frame update
    void Start()
    {

    }
    // Update is called once per frame
    void Update(){
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);  //Input.mousePosition //Input.GetMouseButtonDown(0)
        RaycastHit hit;
        
        
        if (Physics.Raycast(ray,out hit)){
            if(hit.transform.name == transform.name ){

                Vector3 schnittPunkt = hit.point;
                GetComponent<MeshRenderer>().sharedMaterial.SetVector("_Schnittpunkt", schnittPunkt);
                Shader.SetGlobalFloat("_Radius", radius);

                //Texture2D tex = (Texture2D)GetComponent<MeshRenderer>().material.mainTexture;
                //Debug.Log(tex);
                // Vector2 pixelUV = hit.textureCoord;
                //pixelUV.x *= tex.width;
                //pixelUV.y *= tex.height;
                //Vector2 mp = new Vector2(pixelUV.x, pixelUV.y);
                //GetComponent<MeshRenderer>().sharedMaterial.SetVector("_Schnittpunkt", mp);
                //Debug.Log(mp);

                //for (float y = pixelUV.y - radius; y < pixelUV.y + radius; ++y)

                //{
                //    for (float x = pixelUV.x - radius; x < pixelUV.x + radius; ++x)
                //    {
                //        //x^2 ,  y^2
                //        double coordX = Math.Pow((double)Math.Abs(mp.x - x), 2.0);
                //        double coordY = Math.Pow((double)Math.Abs(mp.y - y), 2.0);
                //        //x^2 + y^2 und Wurzel von (x^2 + y^2)
                //        double sum = coordX + coordY;
                //        float coordLen = (float) Math.Sqrt(sum);

                //        if(coordLen <= radius)
                //        {
                //            // r'/r , mischen von Texturfarbe mit Pinselfarbe in Abhaengigkeit der aktuellen Position am Radius (alpha)
                //            alpha = (coordLen / radius) * 0.01f;
                //            alpha = alpha * alpha;
                //            textureColor = tex.GetPixel((int)x, (int)y);
                //            Debug.Log(textureColor);
                //            mixedColor = ((textureColor * alpha) + (testColor * (1 - alpha)));
                //            tex.SetPixel((int)x, (int)y, mixedColor);
                //        }


                //    }
                //}
                //tex.Apply();

                //done = true;
            }
            }
        
    }
}
