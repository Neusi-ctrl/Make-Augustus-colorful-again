﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Basic_PaintAugustus : MonoBehaviour
{
	public float radius = 0.05f;
	public Texture[] textures;
	Renderer rend;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
    	Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
    	RaycastHit hit;

    	if(Physics.Raycast(ray, out hit)){
    		if(hit.transform.name == transform.name){
    			Vector3 schnittPunkt = hit.point;
    			GetComponent<MeshRenderer>().sharedMaterial.SetVector("_Schnittpunkt", schnittPunkt);
    			Shader.SetGlobalFloat("_Radius", radius);
    		}
    	}
    }
}
