﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class PaintAugustus : MonoBehaviour
{
    public Camera drawingcam;
    public GameObject Pinsel;
    public GameObject Radierer;
    public Vector3 schnittPunkt;
    public Texture2D augustusTexture;
    public Texture renderTexture;
    public Texture2D originalTextureColor;
    public bool b;
    //public Image[] Farbpalette = new Image[11];
    //public Image[] Zusatzpalette = new Image[5];
             float radius;
    public Color col;
    public GameObject slider;
    public Image colorPicker;
    //public Image Palettenfarbe;
    public bool dragmove;
    public bool dropmove;
    Vector3 impos;

    // Start is called before the first frame update
    void Start()
    {
        //Initialisierung der Knöpfe: Beim Start soll der Pinsel aktiv sein
        b = Radierer.activeSelf;
        Pinsel.SetActive(!b);
        Radierer.SetActive(b); 

        //Beim Start soll die Pinselgroesse auf eine Standardgroesse eingestellt werden
        //und die Pinselfarbe rot sein
        slider.GetComponent<Slider>().value = 0.3f;
        col = Color.red;
        
        dragmove = false;
        dropmove = false;

        //Hier wird die urspruengliche Textur kopiert um fuer die Radierfunktion verwendet zu werden
        Graphics.CopyTexture(augustusTexture, 0, 0, renderTexture, 0, 0);
        //Graphics.CopyTexture(augustusTexture, originalTextureColor);

     
    }

    // Update is called once per frame
    
    void Update()
    {
        //Tipp von Projektbetreuer, um das UI Problem auf dem Augustus zu loesen
        drawingcam.clearFlags = CameraClearFlags.Nothing;

        //Folgender Code kuemmert sich darum den Strahl, der auf das Objekt gerichtet wird zu erkennen und somit
        //den Schnittpunkt mit dem Objekt auszurechnen.
        //Anschließend werden Schnittpunkt, Farbe, Pinselgroesse, Flag(Pinsel/Radierer) und die kopierte Ursprungstextur an Shader uebergeben
    	Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
    	RaycastHit hit;
        col = colorPicker.GetComponent<Image>().color;

        //Um zu radieren, muss die aktuelle Farbe im Alphakanal auf 0 gesetzt werden
        //die "Farbe" ist die Originaltextur -> EraseTexture
        if (Radierer.active == false){
            col.a = 0.0f;
        }
        if (Physics.Raycast(ray, out hit)){
            if (hit.transform.name == transform.name)
            {
                //wichtig an der Stelle GetMouseButton malt dauernd, wenn linke Maustaste gedrueckt ist
                //GetMouseButtonDown malt nur beim Mausklick! Man muesste also staendig klicken, um zu malen
                if (Input.GetMouseButton(0)){ 
                    schnittPunkt = hit.point;
                    radius = slider.GetComponent<Slider>().value / 10;
                    GetComponent<MeshRenderer>().sharedMaterial.SetVector("_Schnittpunkt", schnittPunkt);
                    Shader.SetGlobalFloat("_Radius", radius);
                    Shader.SetGlobalColor("_TintColor1", col);
                    Shader.SetGlobalFloat("_notPaint", 0);
                    Shader.SetGlobalTexture("_EraseTexture", originalTextureColor);
                } else {
                    Shader.SetGlobalFloat("_notPaint", 1);
                }
            }
    	}
    }
}
