﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class setColor : MonoBehaviour
{
	public Material cushion;
    public GameObject handle;
	private Slider color_changer;
    [HideInInspector]
	public float hue;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        color_changer = this.gameObject.GetComponent<Slider>();
    }

    public void GetColor(){
    	hue = color_changer.value;
    	cushion.SetFloat("_hue", hue);
        Color color_from_hue = Color.HSVToRGB(hue, 1f, 1f);
        handle.GetComponent<Image>().color = color_from_hue;
    }
}
